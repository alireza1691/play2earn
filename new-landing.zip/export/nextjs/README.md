# Plotwar landing — Next.js

Drop-in App Router page. No dependencies beyond Next + React.

## Files

    app/layout.tsx                 fonts + metadata
    app/globals.css                @font-face import, body reset, @keyframes
    app/page.tsx                   renders the component
    components/PlotwarLanding.tsx  the whole landing page

## Install

Copy the four files into an existing Next.js 14/15 project (App Router, TypeScript).
If you are starting fresh:

    npx create-next-app@latest plotwar --ts --app --no-tailwind --eslint
    # then copy app/ and components/ over the generated ones

The `@/components/...` import assumes the default `baseUrl: "."` +
`paths: { "@/*": ["./*"] }` in tsconfig.json that create-next-app writes.
If yours differs, use a relative import.

## Props

    <PlotwarLanding palette="signal" hero="a" />

  palette   'signal' (#FF4D1A, default) | 'green' | 'paper' | 'blue'
            or a tuple: ['#2BE07A', '#0B1410']
            The second value is the text colour used ON the accent; it is
            only honoured if it clears 4.2:1, otherwise ink or paper is
            chosen automatically.

  hero      'a' (default) full-board hero
            'b'           split hero, countdown-led
            'both'        stacks both with 1a / 1b review labels

## Countdown

`MAINNET_OPEN` at the top of PlotwarLanding.tsx is the mainnet date
(1 October 2026, 00:00 UTC). The component is a client component because of it.

## Styling

All styling is inline; the accent is the CSS variable `--pw-accent` set on
the wrapper, with `--pw-on-accent` for text sitting on it. There is no CSS
framework and no class names to collide with.

## Content notes

Numbers on the page follow the game contracts: 10,000 lands on a 100x100 grid
(x,y from 100 to 199), token id = coordinates concatenated, goods accrue every
three hours with a ceiling of 40 x level, warrior stats and barracks gating as
per the roster table, fees 5% on sell/swap/transfer and 10% on withdraw (all
burned). Update them here if the contracts change.
