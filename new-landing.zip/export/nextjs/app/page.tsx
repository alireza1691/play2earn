import PlotwarLanding from '@/components/PlotwarLanding';

export default function Page() {
  return <PlotwarLanding palette="signal" hero="a" />;
}
