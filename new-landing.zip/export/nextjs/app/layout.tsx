import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Plotwar — 10,000 lands, one map',
  description:
    'A 100x100 map of 10,000 lands. Build, recruit, march, and convert goods into $PLOT. Free on Sepolia testnet, mainnet from 1 October.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
